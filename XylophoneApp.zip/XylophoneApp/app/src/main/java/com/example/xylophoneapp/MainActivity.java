package com.example.xylophoneapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //Add member variables
    private int mASoundID;
    private int mBSoundID;
    private int mCSoundID;
    private int mDSoundID;
    private int mESoundID;
    private int mFSoundID;

    //SoundPool Variables
    private SoundPool mSoundPool;
    private final int NUMBER_OF_MAX_STREAMS = 6;
    private final float LEFT_VOLUME = 1.0f;
    private final float RIGHT_VOLUME = 1.0f;
    private final int NO_OF_LOOP = 0;
    private final int PRIORITY = 0;
    private final float NORMAL_PLAY_RATE = 1.0f;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Find Button view by Id
        // Button variables
        Button aButton = findViewById(R.id.a_key);
        Button bButton =findViewById(R.id.b_key);
        Button cButton =findViewById(R.id.c_key);
        Button dButton =findViewById(R.id.d_key);
        Button eButton =findViewById(R.id.e_key);
        Button fButton =findViewById(R.id.f_key);

        //Creating a new SoundPool
        mSoundPool = new SoundPool(NUMBER_OF_MAX_STREAMS,AudioManager.STREAM_MUSIC, 0);

        //Load sound from the raw files which returns a soundID
        mASoundID = mSoundPool.load( this,R.raw.note1_c,1);
        mBSoundID = mSoundPool.load( this,R.raw.note2_d,1);
        mCSoundID = mSoundPool.load( this,R.raw.note3_e,1);
        mDSoundID = mSoundPool.load( this,R.raw.note4_f,1);
        mESoundID = mSoundPool.load( this,R.raw.note5_g,1);
        mFSoundID = mSoundPool.load( this,R.raw.note6_a,1);


        //Setting OnClickListener
        aButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //play music
                mSoundPool.play(mASoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);

            }
        });

        bButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundPool.play(mBSoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);

            }
        });

        cButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mSoundPool.play(mCSoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);
            }
        });
        dButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mSoundPool.play(mDSoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);
            }
        });
        eButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mSoundPool.play(mESoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);
            }
        });
        fButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mSoundPool.play(mFSoundID,LEFT_VOLUME,RIGHT_VOLUME,PRIORITY,NO_OF_LOOP,NORMAL_PLAY_RATE);
            }
        });

    }
}